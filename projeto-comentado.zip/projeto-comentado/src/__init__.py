# Permite que a pasta seja tratada como um pacote Python
# Este arquivo vazio é um marcador que informa ao Python que o diretório
# que o contém deve ser considerado um pacote.
